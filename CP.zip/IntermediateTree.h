

#ifndef _INTERMEDIATE_H
#define _INTERMEDIATE_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAXFUNC 10
#define MACLABEL 100
#define INT_S 0
#define DOUBLE_S 1
#define CHAR_S 2
#define MAXVAR 100

typedef enum { T_plus, T_minus, T_mul, T_div, T_and, T_or, T_lshift, T_rshift, T_arshift, T_xor }T_binOp;
typedef enum { T_eq, T_ne, T_lt, T_gt, T_le, T_ge, T_ult, T_ule, T_ugt, T_uge }T_relOp;
typedef struct T_exp_ *T_exp;
typedef struct T_expList_ *T_expList;
typedef struct T_stm_ *T_stm;


/* Function Table */
struct Func_Node;
struct Node;
struct bucket;
typedef Node *List;
struct bucket {
    char* id;
    void *binding;
    int type;
    int length;
    struct bucket *next;
};
struct Func_Node
{
    char *id;
    T_expList eList;
    T_stm stmt;
    struct bucket *table[MAXVAR];
};
struct Node
{
    struct Func_Node fN;
    Node *next;
};
struct H_FuncTable
{
    int table_size;
    List *table;
};

/* Temp Label */
struct Temp_label_;
typedef Temp_label_ *Temp_label;

struct Temp_label_
{
    char *id;
    T_stm stmt;
    Temp_label next;
};

struct H_LabelTable
{
    int table_size;
    Temp_label *table;
};







struct T_exp_ {
    enum { T_BINOP, T_MEM, T_TEMP, T_ESEQ, T_NAME, T_CONST, T_CALL, T_VARIABLE } kind;
    union {
        struct { T_binOp op; T_exp left, right; }BINOP;
        struct { T_exp exp; }MEM;
        //struct { Temp_temp temp; }TEMP;
        struct { T_stm stm; T_exp exp; }ESEQ;
        struct { char* Name; }NAME;
        struct { char* Const; }CONST;
        struct { T_exp exp; T_expList expList; }CALL;
        struct { char* Variable; }VARIABLE;
    }u;
};
struct T_expList_ { T_exp head; T_expList tail; };

T_expList T_ExpList(T_exp head, T_expList tail);
T_expList join_T_ExpList(T_expList T_el1, T_expList T_el2);
T_exp T_BinOp(T_binOp op, T_exp e1, T_exp e2);
T_exp T_Mem(T_exp exp);
//T_exp T_Temp(Temp_temp temp);
T_exp T_Eseq(T_stm stm, T_exp exp);
T_exp T_Name(char* Name);
T_exp T_Const(char* Const);
T_exp T_Variable(char* Variable);
T_exp T_Call(T_exp exp, T_expList expList);




struct T_stm_ {
	enum { T_SEQ, T_LABEL, T_JUMP, T_CJUMP, T_MOVE, T_EXP, T_PRINT, T_RET} kind;
	union {
		struct { T_stm left, right; }SEQ;
		struct { Temp_label label; }LABEL;
		struct { T_exp exp; Temp_label label; }JUMP;
		struct { T_relOp op; T_exp left; T_exp right; Temp_label True; Temp_label False; }CJUMP;
		struct { T_exp exp1; T_exp exp2; }MOVE;
		struct { T_exp e; }EXP;
		struct { T_stm s; }PRINT;
        struct { T_stm s; }RET;
	}u;
};
T_stm T_Seq(T_stm left, T_stm right);
T_stm T_Label(Temp_label label);
T_stm T_Jump(T_exp exp, Temp_label label);
T_stm T_Cjump(T_relOp op, T_exp left, T_exp right, Temp_label true_l, Temp_label false_l);
T_stm T_Move(T_exp e1, T_exp e2);
T_stm T_Exp(T_exp e);
T_stm T_Print(T_stm s);
T_stm T_Ret(T_stm s);





typedef struct T_stmList_ *T_stmList;
struct T_stmList_ { T_stm head; T_stmList tail; };
T_stmList T_stmList_(T_stm head, T_stm tail);






// structure of function table and label table

H_FuncTable *init_table(int max_size);
Node *find(char *func_name, H_FuncTable *H);
bool insert(char *func_name, T_expList expList, T_stm funcStmt, H_FuncTable *H);
int hash(char *func_name, H_FuncTable *H);
unsigned int hashVar (char *s0);
void insertVariable (int type, int length, char* varname, char* funname, H_FuncTable *H);
struct bucket* Bucket (int type, int length, char* varname, struct bucket* next);
int lookupType (char* varname, char* funname);


Temp_label Temp_label_func();
H_LabelTable *init_label_table(int max_size);
Temp_label *find_label(char *label_name, H_LabelTable *H);
bool insert_label(char *label_name, T_stm labelStmt, H_LabelTable *H);
int hash_label(char *label_name, H_LabelTable *H);



// all scope variables
H_FuncTable *HF = init_table(MAXFUNC);
//H_LabelTable *HL = init_label_table(MACLABEL);
char* current_Func_Name = NULL;























#endif
