#include "IntermediateTree.h"
/* T_stm */
T_stm T_Seq(T_stm left, T_stm right){
	T_stm result = (T_stm)malloc(sizeof(struct T_stm_));
	result->kind = T_stm_::T_SEQ;
	result->u.SEQ.left = left;
	result->u.SEQ.right = right;
	return result;
}
T_stm T_Label(Temp_label label){
	T_stm result = (T_stm)malloc(sizeof(struct T_stm_));
	result->kind = T_stm_::T_LABEL;
	result->u.LABEL.label = label;
	return result;
}
T_stm T_Jump(T_exp exp, Temp_label label){
	T_stm result = (T_stm)malloc(sizeof(struct T_stm_));
	result->kind = T_stm_::T_JUMP;
	result->u.JUMP.exp = exp;
	result->u.JUMP.label = label;
	return result;
}
T_stm T_Cjump(T_relOp op, T_exp left, T_exp right, Temp_label true_l, Temp_label false_l){
	T_stm result = (T_stm)malloc(sizeof(struct T_stm_));
	result->kind = T_stm_::T_CJUMP;
	result->u.CJUMP.op = op;
	result->u.CJUMP.left = left;
	result->u.CJUMP.right = right;
	result->u.CJUMP.True = true_l;
	result->u.CJUMP.False = false_l;
	return result;
}
T_stm T_Move(T_exp e1, T_exp e2){
	T_stm result = (T_stm)malloc(sizeof(struct T_stm_));
	result->kind = T_stm_::T_MOVE;
	result->u.MOVE.exp1 = e1;
	result->u.MOVE.exp2 = e2;
	return result;
}
T_stm T_Exp(T_exp e){
	T_stm result = (T_stm)malloc(sizeof(struct T_stm_));
	result->kind = T_stm_::T_EXP;
	result->u.EXP.e = e;
	return result;
}
T_stm T_Print(T_stm s) {
	T_stm result = (T_stm)malloc(sizeof(struct T_stm_));
	result->kind = T_stm_::T_PRINT;
	result->u.PRINT.s = s;
	return result;
}
T_stm T_Ret(T_stm s) {
	T_stm result = (T_stm)malloc(sizeof(struct T_stm_));
	result->kind = T_stm_::T_RET;
	result->u.RET.s = s;
	//result->u.RET.back = back;
	return result;
}

/* T_exp */
T_exp T_BinOp(T_binOp op, T_exp e1, T_exp e2) {
	T_exp result = (T_exp)malloc(sizeof(struct T_exp_));
	result->kind = T_exp_::T_BINOP;
	result->u.BINOP.op = op;
	result->u.BINOP.left = e1;
	result->u.BINOP.right = e2;
	return result;
}
T_exp T_Mem(T_exp exp) {
	T_exp result = (T_exp)malloc(sizeof(struct T_exp_));
	result->kind = T_exp_::T_MEM;
	result->u.MEM.exp = exp;
	return result;
}
/*
T_exp T_Temp(Temp_temp temp) {
	T_exp result = (T_exp)malloc(sizeof(struct T_exp_));
	result->kind = T_exp_::T_TEMP;
	result->u.TEMP.temp = temp;
	return result;	
}
 */
T_exp T_Eseq(T_stm stm, T_exp exp) {
	T_exp result = (T_exp)malloc(sizeof(struct T_exp_));
	result->kind = T_exp_::T_ESEQ;
	result->u.ESEQ.stm = stm;
	result->u.ESEQ.exp = exp;
	return result;	
}
T_exp T_Name(char* Name) {
	T_exp result = (T_exp)malloc(sizeof(struct T_exp_));
	result->kind = T_exp_::T_NAME;
	result->u.NAME.Name = Name;
	return result;	
}
T_exp T_Const(char* Const) {
	T_exp result = (T_exp)malloc(sizeof(struct T_exp_));
	result->kind = T_exp_::T_CONST;
	result->u.CONST.Const = Const;
	return result;		
}
T_exp T_Variable(char* Variable) {
	T_exp result = (T_exp)malloc(sizeof(struct T_exp_));
	result->kind = T_exp_::T_VARIABLE;
	result->u.VARIABLE.Variable = Variable;
	return result;	
}
T_exp T_Call(T_exp exp, T_expList expList) {
	T_exp result = (T_exp)malloc(sizeof(struct T_exp_));
	result->kind = T_exp_::T_CALL;
	result->u.CALL.exp = exp;
	result->u.CALL.expList = expList;
	return result;		
}

/* expList */
T_expList T_ExpList(T_exp head, T_expList tail) {
	T_expList result = (T_expList)malloc(sizeof(struct T_expList_));
	result->head = head;
	result->tail = tail;
	return result;
}
T_expList join_T_ExpList(T_expList T_el1, T_expList T_el2) {
	if(!T_el1) {
		return T_el2;
	}
	for(; T_el1->tail; T_el1=T_el1->tail);
	T_el1->tail = T_el2;
	return T_el1;
}








// implementation of function table and label


/* Function Table */
H_FuncTable *init_table(int max_size) {
    H_FuncTable *H = (struct H_FuncTable*)malloc(sizeof(struct H_FuncTable));
    H->table_size = max_size;
    H->table = (List*)malloc(sizeof(struct Node)*H->table_size);
    for(int i = 0; i < H->table_size; i++){
        H->table[i] = (Node*)malloc(sizeof(struct Node));
        H->table[i]->fN.id = NULL;
        H->table[i]->fN.eList = NULL;
        H->table[i]->fN.stmt = NULL;
        H->table[i]->next = NULL;
    }
    return H;
}
Node *find(char *func_name, H_FuncTable *H) {
    Node *pos = H->table[hash(func_name, H)];
    pos = pos->next;
    while(pos != NULL && !strcmp(pos->fN.id, func_name)){
        pos = pos->next;
    }
    return pos;
}
bool insert(char *func_name, T_expList expList, T_stm funcStmt, H_FuncTable *H) {
    bool flag = false;
    Node *pos = NULL;
    Node *new_node = NULL;
    if(find(func_name, H) == NULL){
        pos = H->table[hash(func_name, H)];
        new_node = (Node*)malloc(sizeof(struct Node));
        new_node->fN.id = func_name;
        new_node->fN.eList = expList;
        new_node->fN.stmt = funcStmt;
        new_node->next = pos->next;
        pos->next = new_node;
        flag = true;
    }
    return flag;
}
int hash(char *func_name, H_FuncTable *H) {
    int hash = 0;
    while (*func_name){
        hash = (*func_name++) + (hash << 6) + (hash << 16) - hash;
    }
    return (hash & 0x7FFFFFFF) % H->table_size;
}
unsigned int hashVar (char *s0) {
    unsigned int h = 0;
    char *s;
    for (s = s0; *s; s++)
        h = h * 65599 + *s;
    return h % MAXVAR;
}
void insertVariable (int type, int length, char* varname, char* funname, H_FuncTable *H) {
    int funid = hash (funname, H);
    List l;
    for (l = H -> table[funid]; l != NULL; l = l -> next) {
        if (strcmp(funname, l -> fN.id) == 0)
            break;
    }
    if (l == NULL)
        return;
    int varid = hashVar (varname);
    l -> fN.table[varid] = Bucket(type, length, varname, l -> fN.table[varid]);
}
struct bucket* Bucket (int type, int length, char* varname, struct bucket* next) {
    struct bucket* b = (struct bucket*)malloc(sizeof(struct bucket));
    b -> type = type;
    b -> length = length;
    b -> id = varname;
    b -> next = next;
    return b;
}
int lookupType (char* varname, char* funname, H_FuncTable *H) {
    int funid = hash (funname, H);
    List l;
    for (l = H -> table[funid]; l != NULL; l = l -> next) {
        if (strcmp(funname, l -> fN.id) == 0)
            break;
    }
    if (l == NULL)
        return -1;
    int varid = hashVar (varname);
    struct bucket* b;
    for (b = l->fN.table[varid]; b != NULL; b=b->next) {
        if (strcmp(varname, b -> id) == 0)
            break;
    }
    if (b == NULL)
        return -1;
    return b->type;
}



/* Temp Label */
Temp_label Temp_label_func() {
  Temp_label t = (Temp_label)malloc(sizeof(struct Temp_label_));
  return t;
}
                                      
/*H_LabelTable *init_label_table(int max_size) {
    H_LabelTable *H = (struct H_LabelTable*)malloc(sizeof(struct H_LabelTable));
    H->table_size = max_size;
    H->table = (Temp_label*)malloc(sizeof(struct Temp_label_)*H->table_size);
    for(int i = 0; i < H->table_size; i++){
        H->table[i] = (Temp_label)malloc(sizeof(struct Temp_label_));
        H->table[i]->id = NULL;
        H->table[i]->stmt = NULL;
        H->table[i]->next = NULL;
    }
    return H;
}

Temp_label find_label(char *label_name, H_LabelTable *H){
    Temp_label pos = H->table[hash_label(label_name, H)];
    pos = pos->next;
    while(pos != NULL && !strcmp(pos->id, label_name)){
        pos = pos->next;
    }
    return pos;
}

bool insert_label(char *label_name, T_stm labelStmt, H_LabelTable *H){
    bool flag = false;
    Temp_label_ *pos = NULL;
    Temp_label_ *new_node = NULL;
    if(find(label_name, H) == NULL){
        pos = H->table[hash(label_name, H)];
        new_node = (Temp_label)malloc(sizeof(struct Temp_label_));
        new_node->id = label_name;
        new_node->stmt = labelStmt;
        new_node->next = pos->next;
        pos->next = new_node;
        flag = true;
    }
    return flag;
}

int hash_label(char *label_name, H_LabelTable *H){
    int hash = 0;
    while (*label_name){
        hash = (*label_name++) + (hash << 6) + (hash << 16) - hash;
    }
    return (hash & 0x7FFFFFFF) % H->table_size;
}*/






